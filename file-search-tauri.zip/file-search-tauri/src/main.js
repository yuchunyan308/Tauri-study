import { invoke } from "@tauri-apps/api/core";
import { open } from "@tauri-apps/plugin-dialog";

const addFolderBtn = document.getElementById("addFolderBtn");
const enableWatchEl = document.getElementById("enableWatch");
const pathListEl = document.getElementById("pathList");
const buildBtn = document.getElementById("buildBtn");
const buildStatus = document.getElementById("buildStatus");

const searchInput = document.getElementById("searchInput");
const matchCaseEl = document.getElementById("matchCase");
const useRegexEl = document.getElementById("useRegex");
const extFilterEl = document.getElementById("extFilter");
const statsBar = document.getElementById("statsBar");
const resultTableBody = document.querySelector("#resultTable tbody");
const statusText = document.getElementById("statusText");

let indexPaths = [];
let searchDebounceTimer = null;
let indexed = false;

addFolderBtn.addEventListener("click", async () => {
  try {
    const selected = await open({ directory: true, multiple: false });
    if (selected && !indexPaths.includes(selected)) {
      indexPaths.push(selected);
      renderPathList();
    }
  } catch (e) {
    statusText.textContent = "选择文件夹失败: " + e;
  }
});

function renderPathList() {
  pathListEl.innerHTML = "";
  indexPaths.forEach((p, idx) => {
    const row = document.createElement("div");
    row.className = "path-item";
    row.innerHTML = `
      <span>${escapeHtml(p)}</span>
      <button class="remove-btn" data-idx="${idx}">✕</button>
    `;
    row.querySelector(".remove-btn").addEventListener("click", () => {
      indexPaths.splice(idx, 1);
      renderPathList();
    });
    pathListEl.appendChild(row);
  });
  buildBtn.disabled = indexPaths.length === 0;
}

buildBtn.addEventListener("click", async () => {
  if (indexPaths.length === 0) return;
  buildBtn.disabled = true;
  addFolderBtn.disabled = true;
  buildStatus.textContent = "正在扫描并建立索引，文件较多时可能需要一些时间...";
  statusText.textContent = "建立索引中...";

  try {
    const result = await invoke("build_index", {
      paths: indexPaths,
      enableWatch: enableWatchEl.checked,
    });
    indexed = true;
    searchInput.disabled = false;
    searchInput.focus();

    let msg = `索引完成：共 ${result.total_files} 个文件、${result.total_dirs} 个文件夹，耗时 ${(result.elapsed_ms / 1000).toFixed(1)} 秒。`;
    if (result.skipped_paths && result.skipped_paths.length > 0) {
      msg += ` 跳过：${result.skipped_paths.join("; ")}`;
    }
    buildStatus.textContent = msg;
    statusText.textContent = enableWatchEl.checked
      ? "索引就绪，已开启实时监控 ✅"
      : "索引就绪（未开启实时监控，磁盘变化不会自动同步）";

    await refreshStats();
    if (searchInput.value.trim()) {
      doSearch();
    }
  } catch (e) {
    buildStatus.textContent = "建立索引失败: " + e;
    statusText.textContent = "建立索引失败";
  } finally {
    buildBtn.disabled = false;
    addFolderBtn.disabled = false;
  }
});

searchInput.addEventListener("input", () => {
  clearTimeout(searchDebounceTimer);
  searchDebounceTimer = setTimeout(doSearch, 150);
});
matchCaseEl.addEventListener("change", doSearch);
useRegexEl.addEventListener("change", doSearch);
extFilterEl.addEventListener("input", () => {
  clearTimeout(searchDebounceTimer);
  searchDebounceTimer = setTimeout(doSearch, 150);
});
document.querySelectorAll('input[name="typeFilter"]').forEach((r) => {
  r.addEventListener("change", doSearch);
});

async function doSearch() {
  if (!indexed) return;
  const typeFilter = document.querySelector('input[name="typeFilter"]:checked').value;

  try {
    const result = await invoke("search_files", {
      options: {
        query: searchInput.value,
        matchCase: matchCaseEl.checked,
        useRegex: useRegexEl.checked,
        onlyFiles: typeFilter === "files",
        onlyDirs: typeFilter === "dirs",
        extension: extFilterEl.value.trim(),
        limit: 500,
      },
    });
    renderResults(result);
  } catch (e) {
    statusText.textContent = "搜索出错: " + e;
  }
}

function renderResults(result) {
  statsBar.textContent = result.truncated
    ? `已索引 ${result.total_indexed} 项，结果过多，仅显示前 ${result.results.length} 条，请输入更精确的关键字缩小范围`
    : `已索引 ${result.total_indexed} 项，匹配到 ${result.results.length} 条结果`;

  resultTableBody.innerHTML = "";
  for (const item of result.results) {
    const tr = document.createElement("tr");
    const icon = item.is_dir ? "📁" : "📄";
    const sizeText = item.is_dir ? "-" : formatSize(item.size);
    const dateText = formatDate(item.modified);
    tr.innerHTML = `
      <td>${icon}</td>
      <td class="name-cell" title="${escapeAttr(item.name)}">${escapeHtml(item.name)}</td>
      <td class="path-cell" title="${escapeAttr(item.path)}">${escapeHtml(item.path)}</td>
      <td>${sizeText}</td>
      <td>${dateText}</td>
      <td>
        <button class="action-btn open-btn">打开</button>
        <button class="action-btn reveal-btn">定位</button>
      </td>
    `;
    tr.querySelector(".open-btn").addEventListener("click", () => {
      invoke("open_path", { path: item.path }).catch((e) => {
        statusText.textContent = "打开失败: " + e;
      });
    });
    tr.querySelector(".reveal-btn").addEventListener("click", () => {
      invoke("reveal_in_folder", { path: item.path }).catch((e) => {
        statusText.textContent = "定位失败: " + e;
      });
    });
    resultTableBody.appendChild(tr);
  }
}

async function refreshStats() {
  try {
    const stats = await invoke("get_stats");
    if (stats.last_built) {
      const d = new Date(stats.last_built * 1000);
      buildStatus.title = `最近一次建立索引时间: ${d.toLocaleString()}`;
    }
  } catch (e) {
    // 忽略
  }
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let val = bytes / 1024;
  let i = 0;
  while (val >= 1024 && i < units.length - 1) {
    val /= 1024;
    i++;
  }
  return `${val.toFixed(1)} ${units[i]}`;
}

function formatDate(ts) {
  if (!ts) return "-";
  const d = new Date(ts * 1000);
  return d.toLocaleString();
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

function escapeAttr(str) {
  return (str ?? "").replace(/"/g, "&quot;");
}
