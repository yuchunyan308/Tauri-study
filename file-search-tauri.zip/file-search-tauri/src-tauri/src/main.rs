#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use regex::Regex;
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::sync::mpsc::RecvTimeoutError;
use std::sync::Mutex;
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use tauri::{AppHandle, Manager, State};

// ---------- 数据结构 ----------

#[derive(Serialize, Clone)]
struct FileEntry {
    path: String,
    name: String,
    #[serde(skip_serializing)]
    name_lower: String,
    is_dir: bool,
    size: u64,
    modified: i64,
    extension: String,
}

struct IndexState {
    entries: Mutex<Vec<FileEntry>>,
    indexed_paths: Mutex<Vec<String>>,
    last_built: Mutex<Option<i64>>,
    watch_generation: Mutex<u64>,
    building: Mutex<bool>,
}

impl Default for IndexState {
    fn default() -> Self {
        IndexState {
            entries: Mutex::new(Vec::new()),
            indexed_paths: Mutex::new(Vec::new()),
            last_built: Mutex::new(None),
            watch_generation: Mutex::new(0),
            building: Mutex::new(false),
        }
    }
}

#[derive(Serialize)]
struct IndexBuildResult {
    total_files: usize,
    total_dirs: usize,
    elapsed_ms: u64,
    skipped_paths: Vec<String>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct SearchOptions {
    query: String,
    match_case: bool,
    use_regex: bool,
    only_files: bool,
    only_dirs: bool,
    extension: String, // 空字符串表示不限
    limit: usize,
}

#[derive(Serialize)]
struct SearchResult {
    results: Vec<FileEntry>,
    truncated: bool,
    total_indexed: usize,
}

#[derive(Serialize)]
struct IndexStats {
    total_entries: usize,
    indexed_paths: Vec<String>,
    last_built: Option<i64>,
    building: bool,
}

fn now_ts() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0)
}

fn file_time_to_ts(t: std::io::Result<SystemTime>) -> i64 {
    t.ok()
        .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0)
}

fn make_entry(path: &Path) -> Option<FileEntry> {
    let metadata = std::fs::symlink_metadata(path).ok()?;
    let name = path.file_name()?.to_string_lossy().to_string();
    let extension = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();
    Some(FileEntry {
        path: path.to_string_lossy().to_string(),
        name_lower: name.to_lowercase(),
        name,
        is_dir: metadata.is_dir(),
        size: metadata.len(),
        modified: file_time_to_ts(metadata.modified()),
        extension,
    })
}

// ---------- 建立索引 ----------

#[tauri::command]
fn build_index(
    paths: Vec<String>,
    enable_watch: bool,
    state: State<IndexState>,
    app_handle: AppHandle,
) -> Result<IndexBuildResult, String> {
    if paths.is_empty() {
        return Err("请至少选择一个要索引的文件夹或磁盘".to_string());
    }

    {
        let mut building = state.building.lock().map_err(|e| e.to_string())?;
        if *building {
            return Err("正在建立索引中，请稍候".to_string());
        }
        *building = true;
    }

    let start = std::time::Instant::now();
    let mut new_entries: Vec<FileEntry> = Vec::new();
    let mut file_count = 0usize;
    let mut dir_count = 0usize;
    let mut skipped_paths = Vec::new();

    for root in &paths {
        let root_path = Path::new(root);
        if !root_path.exists() {
            skipped_paths.push(format!("{}（路径不存在）", root));
            continue;
        }
        for entry in walkdir::WalkDir::new(root_path)
            .into_iter()
            .filter_map(|e| e.ok())
        {
            let path = entry.path();
            if let Some(fe) = make_entry(path) {
                if fe.is_dir {
                    dir_count += 1;
                } else {
                    file_count += 1;
                }
                new_entries.push(fe);
            }
        }
    }

    {
        let mut entries = state.entries.lock().map_err(|e| e.to_string())?;
        *entries = new_entries;
    }
    {
        let mut idx_paths = state.indexed_paths.lock().map_err(|e| e.to_string())?;
        *idx_paths = paths.clone();
    }
    {
        let mut last_built = state.last_built.lock().map_err(|e| e.to_string())?;
        *last_built = Some(now_ts());
    }
    {
        let mut building = state.building.lock().map_err(|e| e.to_string())?;
        *building = false;
    }

    if enable_watch {
        start_watchers(paths, app_handle);
    } else {
        // 关闭实时监控：递增代数，让旧的监控线程自然退出
        let mut g = state.watch_generation.lock().map_err(|e| e.to_string())?;
        *g += 1;
    }

    let elapsed_ms = start.elapsed().as_millis() as u64;
    Ok(IndexBuildResult {
        total_files: file_count,
        total_dirs: dir_count,
        elapsed_ms,
        skipped_paths,
    })
}

// ---------- 搜索 ----------

#[tauri::command]
fn search_files(options: SearchOptions, state: State<IndexState>) -> Result<SearchResult, String> {
    let entries = state.entries.lock().map_err(|e| e.to_string())?;
    let limit = if options.limit == 0 { 500 } else { options.limit };
    let ext_filter = options.extension.trim().to_lowercase();

    let regex_matcher: Option<Regex> = if options.use_regex && !options.query.is_empty() {
        let pattern = if options.match_case {
            options.query.clone()
        } else {
            format!("(?i){}", options.query)
        };
        Some(Regex::new(&pattern).map_err(|e| format!("正则表达式错误: {}", e))?)
    } else {
        None
    };

    let query_lower = options.query.to_lowercase();

    let mut results = Vec::new();
    let mut truncated = false;

    for entry in entries.iter() {
        if options.only_files && entry.is_dir {
            continue;
        }
        if options.only_dirs && !entry.is_dir {
            continue;
        }
        if !ext_filter.is_empty() && entry.extension != ext_filter {
            continue;
        }
        if !options.query.is_empty() {
            let is_match = if let Some(re) = &regex_matcher {
                re.is_match(&entry.name)
            } else if options.match_case {
                entry.name.contains(options.query.as_str())
            } else {
                entry.name_lower.contains(query_lower.as_str())
            };
            if !is_match {
                continue;
            }
        }

        if results.len() >= limit {
            truncated = true;
            break;
        }
        results.push(entry.clone());
    }

    Ok(SearchResult {
        results,
        truncated,
        total_indexed: entries.len(),
    })
}

#[tauri::command]
fn get_stats(state: State<IndexState>) -> Result<IndexStats, String> {
    let entries = state.entries.lock().map_err(|e| e.to_string())?;
    let indexed_paths = state.indexed_paths.lock().map_err(|e| e.to_string())?;
    let last_built = state.last_built.lock().map_err(|e| e.to_string())?;
    let building = state.building.lock().map_err(|e| e.to_string())?;
    Ok(IndexStats {
        total_entries: entries.len(),
        indexed_paths: indexed_paths.clone(),
        last_built: *last_built,
        building: *building,
    })
}

// ---------- 打开文件 / 定位到文件夹 ----------

#[tauri::command]
fn open_path(path: String) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        std::process::Command::new("cmd")
            .args(["/C", "start", "", &path])
            .spawn()
            .map_err(|e| format!("打开失败: {}", e))?;
    }
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("open")
            .arg(&path)
            .spawn()
            .map_err(|e| format!("打开失败: {}", e))?;
    }
    #[cfg(target_os = "linux")]
    {
        std::process::Command::new("xdg-open")
            .arg(&path)
            .spawn()
            .map_err(|e| format!("打开失败: {}", e))?;
    }
    Ok(())
}

#[tauri::command]
fn reveal_in_folder(path: String) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        std::process::Command::new("explorer")
            .arg(format!("/select,{}", path))
            .spawn()
            .map_err(|e| format!("打开失败: {}", e))?;
    }
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("open")
            .args(["-R", &path])
            .spawn()
            .map_err(|e| format!("打开失败: {}", e))?;
    }
    #[cfg(target_os = "linux")]
    {
        let dir = Path::new(&path)
            .parent()
            .map(|p| p.to_string_lossy().to_string())
            .unwrap_or_else(|| path.clone());
        std::process::Command::new("xdg-open")
            .arg(&dir)
            .spawn()
            .map_err(|e| format!("打开失败: {}", e))?;
    }
    Ok(())
}

// ---------- 实时文件监控（保持索引与磁盘同步）----------

fn start_watchers(paths: Vec<String>, app_handle: AppHandle) {
    let my_gen: u64 = {
        let state = app_handle.state::<IndexState>();
        let mut g = state.watch_generation.lock().unwrap();
        *g += 1;
        *g
    };

    std::thread::spawn(move || {
        use notify::{RecursiveMode, Watcher};

        let (tx, rx) = std::sync::mpsc::channel();
        let watcher_result = notify::recommended_watcher(move |res| {
            let _ = tx.send(res);
        });

        let mut watcher = match watcher_result {
            Ok(w) => w,
            Err(_) => return,
        };

        for p in &paths {
            let _ = watcher.watch(Path::new(p), RecursiveMode::Recursive);
        }

        loop {
            // 每次都检查代数，若已被新的索引构建取代，则退出线程，
            // watcher 随之被 drop，自动停止监听，避免多个监控线程同时更新索引。
            {
                let state = app_handle.state::<IndexState>();
                let current_gen = *state.watch_generation.lock().unwrap();
                if current_gen != my_gen {
                    break;
                }
            }

            match rx.recv_timeout(Duration::from_millis(500)) {
                Ok(Ok(event)) => apply_event(&app_handle, event),
                Ok(Err(_)) => {}
                Err(RecvTimeoutError::Timeout) => {}
                Err(RecvTimeoutError::Disconnected) => break,
            }
        }
    });
}

fn apply_event(app_handle: &AppHandle, event: notify::Event) {
    use notify::EventKind;

    let state = app_handle.state::<IndexState>();
    let mut entries = match state.entries.lock() {
        Ok(e) => e,
        Err(_) => return,
    };

    match event.kind {
        EventKind::Remove(_) => {
            for p in &event.paths {
                let p_str = p.to_string_lossy().to_string();
                entries.retain(|e| e.path != p_str);
            }
        }
        EventKind::Create(_) | EventKind::Modify(_) => {
            for p in &event.paths {
                let p_str = p.to_string_lossy().to_string();
                entries.retain(|e| e.path != p_str);
                if let Some(fe) = make_entry(p) {
                    entries.push(fe);
                }
            }
        }
        _ => {}
    }
}

fn main() {
    tauri::Builder::default()
        .manage(IndexState::default())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .invoke_handler(tauri::generate_handler![
            build_index,
            search_files,
            get_stats,
            open_path,
            reveal_in_folder
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
