# 🔄 文件互转助手（Tauri 版）

基于 **Tauri 2 + Rust + 原生前端** 的常见文档格式互转工具，支持在 **TXT / Markdown / HTML / DOCX / PDF** 之间批量互转。

## ✨ 功能特点

- **批量选择多个文件**，统一转换为指定的目标格式
- **5 种格式互转**：TXT、Markdown（.md）、HTML、DOCX（Word）、PDF
- **转换前预览**：点击文件列表中的某一项，可先查看抽取出的纯文本内容，确认无误再转换
- **PDF 内嵌中文字体**：内置开源「文泉驿正黑」字体，转换出的 PDF 可正常显示中文，不会出现方块乱码
- **自动去重命名**：目标位置已有同名文件时自动加序号，不会覆盖原文件
- **自检机制**：每次转换后自动核对——
  1. 成功数 + 跳过数 + 出错数 = 文件总数
  2. 所有标记为"成功"的输出文件必须真实存在且大小不为 0
  3. 校验结果以 ✅ / ⚠️ 显示在界面上，并写入原文件夹内的 `转换日志_时间戳.txt`
- 源格式与目标格式相同时自动跳过，不做无意义转换

## 📐 支持的转换矩阵

| 源 \ 目标 | TXT | MD | HTML | DOCX | PDF |
|---|---|---|---|---|---|
| **TXT** | - | ✅ | ✅ | ✅ | ✅ |
| **MD** | ✅ | - | ✅（高保真渲染） | ✅ | ✅ |
| **HTML** | ✅ | ✅（转纯文本） | - | ✅ | ✅ |
| **DOCX** | ✅ | ✅ | ✅ | - | ✅ |
| **PDF** | ✅ | ✅ | ✅ | ✅ | - |

## ⚠️ 关于格式转换的真实能力边界（请务必先读）

这是一个**基于纯文本抽取/重排版**的轻量转换工具，不是 Pandoc 或 Word/Adobe 那样的重型排版引擎。请如实了解以下限制，避免抱有过高期待：

1. **只处理文字内容，不保留原始排版/样式**：字体、颜色、表格结构、图片、页眉页脚等在转换中不会被保留（HTML→其他格式时会丢弃样式，只保留段落文字）。Markdown → HTML 会高保真渲染（标题、列表、粗斜体、链接等），但反过来其他格式 → Markdown 只能得到纯文本段落，不会自动重建 Markdown 语法。
2. **仅支持 `.docx`（Office Open XML），不支持旧版二进制 `.doc`**（Word 97-2003）。如果你的文件是 `.doc`，请先用 Word/WPS 另存为 `.docx` 再转换。
3. **PDF 只能处理"文字型 PDF"**，无法识别扫描件/图片型 PDF 中的文字（没有做 OCR）。
4. **生成的 PDF 是简单的纯文本流版式**（自动换行 + 自动分页），不会还原源文件的图文混排布局——适合"快速把内容导成 PDF"，不适合正式排版出版需求。
5. **加密/受密码保护的文档**不支持读取。

如果你需要的是"完整保留原始排版"的高保真转换（例如 Word 转 PDF 要求版式像素级一致），建议使用 Microsoft Word、WPS、LibreOffice 或 Pandoc 等专业工具；本工具定位是"内容快速互转的小工具"。

## 🔧 关于本压缩包 —— 重要说明

同上一个项目一样，**本沙箱环境没有联网权限、也没有安装 Rust 工具链**，因此我**无法在这里直接编译出可双击运行的安装包**。压缩包内是**完整、可直接构建**的 Tauri 项目源码，请按以下步骤在你自己电脑上构建。

## 🔧 本地构建步骤

### 1. 安装前置环境（只需一次）

- **Node.js** 18+：https://nodejs.org
- **Rust**：https://www.rust-lang.org/tools/install
- 系统依赖（Tauri 官方要求）：
  - Windows：Visual Studio C++ Build Tools + WebView2（Win10/11 通常自带）
  - macOS：`xcode-select --install`
  - Linux：参考 https://tauri.app/start/prerequisites/ 安装 `libwebkit2gtk`、`libgtk-3-dev` 等

### 2. 安装依赖并运行

```bash
cd file-converter-tauri
npm install     # 安装前端依赖
npm run dev      # 开发模式体验
```

首次 `npm run dev` / `npm run build` 时，Cargo 会自动联网下载 Rust 依赖包（pulldown-cmark、printpdf、pdf-extract、zip、regex 等），请确保联网。

### 3. 打包成正式安装包

```bash
npm run build
```

产物在 `src-tauri/target/release/bundle/` 下：
- Windows → `nsis/*.exe` 或 `msi/*.msi`
- macOS → `dmg/*.dmg`
- Linux → `deb/*.deb`、`appimage/*.AppImage`

双击即可安装启动，之后无需再依赖 Node/Rust 环境。

## 📂 项目结构

```
file-converter-tauri/
├── package.json
├── src/                        # 前端（原生 HTML/CSS/JS）
│   ├── index.html
│   ├── style.css
│   └── main.js
└── src-tauri/
    ├── Cargo.toml
    ├── build.rs
    ├── tauri.conf.json
    ├── capabilities/default.json
    ├── icons/
    ├── assets/fonts/wqy-zenhei.ttf   # 内嵌中文字体（用于生成PDF）
    └── src/
        ├── main.rs        # Tauri 命令、批量转换调度、自检、日志
        ├── converter.rs   # 中间表示、TXT/MD/HTML 的抽取与渲染逻辑
        ├── docx_util.rs   # docx 的读取（unzip+正则解析）与生成（手写最小OOXML）
        └── pdf_util.rs    # PDF 文本抽取（pdf-extract）与生成（printpdf + 内嵌中文字体）
```

## 🧪 我在提交前做的自检

1. **代码走查**：逐个模块检查了抽取/渲染的匹配逻辑、docx 的 zip+XML 读写、PDF 分页换行逻辑，确认没有死循环、没有遗漏的 match 分支。
2. **格式与语法校验**：`node --check` 校验了前端 JS 语法；Python `json.load` 校验了 `tauri.conf.json`、`capabilities/default.json`、`package.json` 均为合法 JSON。
3. **字体校验**：用于 PDF 中文渲染的字体文件已用 `fontTools` 验证——可正常加载、包含中文字形（验证了"中""文"等字的字形存在）。
4. **依赖版本谨慎选择**：docx 的读写没有依赖易变的第三方 docx 库 API，而是直接手写符合 OOXML 规范的最小合法结构（`[Content_Types].xml` + `_rels/.rels` + `word/document.xml`），降低因库版本差异导致编译失败或行为不一致的风险。
5. **未做到的**：同样由于沙箱无网络、无 Rust 工具链，**未能实际执行 `cargo build` 编译验证**，也没有跑真实文件做端到端转换测试。这是本次交付如实告知的局限——如果本地构建时报错（多为 Tauri/Rust 依赖版本差异），把报错信息发给我，我可以继续帮你排查修复。

## 🛡️ 使用建议

- 转换前先点开文件预览一下，确认抽取到的文字内容符合预期
- 重要文档建议先转一份试试效果，确认满意后再批量处理
- 如果 PDF/DOCX 抽取不出内容，大概率是扫描件图片或加密文档，本工具无法处理这两类
