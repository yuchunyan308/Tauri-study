use regex::Regex;
use std::fs;
use std::io::{Read, Write};
use std::path::Path;

const CONTENT_TYPES_XML: &str = r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"#;

const RELS_XML: &str = r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"#;

/// 从 .docx（本质是一个 zip 包）中提取纯文本段落。
/// 仅支持 .docx（Office Open XML），不支持旧版二进制 .doc（Word 97-2003）。
pub fn extract_docx_paragraphs(path: &Path) -> Result<Vec<String>, String> {
    let file = fs::File::open(path).map_err(|e| format!("打开 docx 文件失败: {}", e))?;
    let mut archive =
        zip::ZipArchive::new(file).map_err(|e| format!("无法解析 docx 文件结构（可能不是有效的 .docx，也许是旧版 .doc？）: {}", e))?;

    let mut doc_xml = String::new();
    {
        let mut entry = archive
            .by_name("word/document.xml")
            .map_err(|e| format!("未在 docx 中找到 word/document.xml: {}", e))?;
        entry
            .read_to_string(&mut doc_xml)
            .map_err(|e| format!("读取 document.xml 失败: {}", e))?;
    }

    let re_t = Regex::new(r"(?s)<w:t[^>]*>(.*?)</w:t>").unwrap();
    let mut paragraphs = Vec::new();

    for para_xml in doc_xml.split("</w:p>") {
        let mut para_text = String::new();
        for cap in re_t.captures_iter(para_xml) {
            para_text.push_str(&decode_xml_entities(&cap[1]));
        }
        let trimmed = para_text.trim();
        if !trimmed.is_empty() {
            paragraphs.push(trimmed.to_string());
        }
    }

    if paragraphs.is_empty() {
        return Err("未能从该 docx 文件中提取到文本内容（可能是空文档、扫描件或加密文档）".to_string());
    }
    Ok(paragraphs)
}

/// 生成一个最小但合法的 .docx 文件（每个段落对应一个 <w:p>，段落内换行拆分为多行）
pub fn write_docx(paragraphs: &[String], out_path: &Path) -> Result<(), String> {
    let file = fs::File::create(out_path).map_err(|e| format!("创建 docx 文件失败: {}", e))?;
    let mut zip = zip::ZipWriter::new(file);
    let options = zip::write::FileOptions::default().compression_method(zip::CompressionMethod::Deflated);

    zip.start_file("[Content_Types].xml", options)
        .map_err(|e| e.to_string())?;
    zip.write_all(CONTENT_TYPES_XML.as_bytes())
        .map_err(|e| e.to_string())?;

    zip.start_file("_rels/.rels", options)
        .map_err(|e| e.to_string())?;
    zip.write_all(RELS_XML.as_bytes()).map_err(|e| e.to_string())?;

    zip.start_file("word/document.xml", options)
        .map_err(|e| e.to_string())?;
    let document_xml = build_document_xml(paragraphs);
    zip.write_all(document_xml.as_bytes())
        .map_err(|e| e.to_string())?;

    zip.finish().map_err(|e| format!("写入 docx 压缩包失败: {}", e))?;
    Ok(())
}

fn build_document_xml(paragraphs: &[String]) -> String {
    let mut body = String::new();
    for para in paragraphs {
        if para.trim().is_empty() {
            body.push_str("<w:p/>");
            continue;
        }
        for line in para.split('\n') {
            body.push_str("<w:p><w:r><w:t xml:space=\"preserve\">");
            body.push_str(&escape_xml(line));
            body.push_str("</w:t></w:r></w:p>");
        }
    }
    format!(
        r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body>
{body}
<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>
</w:body>
</w:document>"#,
        body = body
    )
}

fn escape_xml(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

fn decode_xml_entities(s: &str) -> String {
    s.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
}
