use printpdf::{Mm, PdfDocument};
use std::fs;
use std::io::{BufWriter, Cursor};
use std::path::Path;

/// 内嵌开源中文字体（文泉驿正黑，Apache/GPL 授权可自由分发），
/// 保证生成的 PDF 中中文字符能够正常显示，而不是使用只覆盖拉丁字符的内置字体。
static CJK_FONT_BYTES: &[u8] = include_bytes!("../assets/fonts/wqy-zenhei.ttf");

const PAGE_WIDTH_MM: f64 = 210.0;
const PAGE_HEIGHT_MM: f64 = 297.0;
const MARGIN_MM: f64 = 18.0;
const FONT_SIZE_PT: f64 = 12.0;
const LINE_HEIGHT_MM: f64 = 7.0;
const CHARS_PER_LINE: usize = 40;

/// 从 PDF 中提取文本段落（不支持扫描件/图片型 PDF，因为其本身没有文本层）
pub fn extract_pdf_paragraphs(path: &Path) -> Result<Vec<String>, String> {
    let text = pdf_extract::extract_text(path).map_err(|e| {
        format!(
            "PDF 文本提取失败（可能是扫描件图片型 PDF，或文档已加密）: {}",
            e
        )
    })?;

    let mut paragraphs: Vec<String> = text
        .replace("\r\n", "\n")
        .split("\n\n")
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();

    if paragraphs.is_empty() {
        paragraphs = text
            .lines()
            .map(|l| l.trim().to_string())
            .filter(|l| !l.is_empty())
            .collect();
    }

    if paragraphs.is_empty() {
        return Err("未能从该 PDF 中提取到文字内容，可能是扫描件图片 PDF".to_string());
    }
    Ok(paragraphs)
}

/// 将纯文本段落渲染为一个排版简单的多页 PDF（自动换行 + 自动分页）
pub fn write_pdf(paragraphs: &[String], out_path: &Path) -> Result<(), String> {
    let page_width = Mm(PAGE_WIDTH_MM);
    let page_height = Mm(PAGE_HEIGHT_MM);
    let top_y = PAGE_HEIGHT_MM - MARGIN_MM;

    let (doc, page1, layer1) =
        PdfDocument::new("Converted Document", page_width, page_height, "Layer 1");
    let font = doc
        .add_external_font(Cursor::new(CJK_FONT_BYTES))
        .map_err(|e| format!("字体加载失败: {}", e))?;

    let mut page_idx = page1;
    let mut layer_idx = layer1;
    let mut y = top_y;

    if paragraphs.is_empty() {
        let layer = doc.get_page(page_idx).get_layer(layer_idx);
        layer.use_text("(空文档)", FONT_SIZE_PT, Mm(MARGIN_MM), Mm(y), &font);
    }

    for para in paragraphs {
        for line in wrap_text(para, CHARS_PER_LINE) {
            if y < MARGIN_MM {
                let (p, l) = doc.add_page(page_width, page_height, "Layer 1");
                page_idx = p;
                layer_idx = l;
                y = top_y;
            }
            let layer = doc.get_page(page_idx).get_layer(layer_idx);
            layer.use_text(line.as_str(), FONT_SIZE_PT, Mm(MARGIN_MM), Mm(y), &font);
            y -= LINE_HEIGHT_MM;
        }
        // 段落间空一点距离
        y -= LINE_HEIGHT_MM * 0.5;
    }

    let file = fs::File::create(out_path).map_err(|e| format!("创建 PDF 文件失败: {}", e))?;
    doc.save(&mut BufWriter::new(file))
        .map_err(|e| format!("保存 PDF 失败: {}", e))?;
    Ok(())
}

/// 按字符数做简单换行（兼顾中文字符，不按字节切分，避免破坏多字节字符）
fn wrap_text(text: &str, max_chars: usize) -> Vec<String> {
    let mut lines = Vec::new();
    for raw_line in text.split('\n') {
        let chars: Vec<char> = raw_line.chars().collect();
        if chars.is_empty() {
            lines.push(String::new());
            continue;
        }
        for chunk in chars.chunks(max_chars) {
            lines.push(chunk.iter().collect::<String>());
        }
    }
    lines
}
