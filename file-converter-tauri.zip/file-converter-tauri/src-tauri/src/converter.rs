use regex::Regex;
use std::fs;
use std::path::{Path, PathBuf};

use crate::docx_util;
use crate::pdf_util;

/// 中间表示：
/// - Markdown: 保留原始 Markdown 源码（用于高保真渲染为 HTML）
/// - Paragraphs: 已拆分好的纯文本段落（适用于 txt/docx/pdf 以及非 md 来源）
pub enum Intermediate {
    Markdown(String),
    Paragraphs(Vec<String>),
}

/// 支持的格式集合（用于前端展示与校验）
pub const SUPPORTED_FORMATS: [&str; 5] = ["txt", "md", "html", "docx", "pdf"];

pub fn normalize_ext(ext: &str) -> String {
    let e = ext.to_lowercase();
    match e.as_str() {
        "markdown" => "md".to_string(),
        "htm" => "html".to_string(),
        other => other.to_string(),
    }
}

/// ---------- 抽取（Extract）----------

pub fn extract(path: &Path, ext: &str) -> Result<Intermediate, String> {
    match ext {
        "txt" => {
            let content = fs::read_to_string(path).map_err(|e| format!("读取 TXT 失败: {}", e))?;
            Ok(Intermediate::Paragraphs(split_paragraphs(&content)))
        }
        "md" => {
            let content =
                fs::read_to_string(path).map_err(|e| format!("读取 Markdown 失败: {}", e))?;
            Ok(Intermediate::Markdown(content))
        }
        "html" => {
            let content = fs::read_to_string(path).map_err(|e| format!("读取 HTML 失败: {}", e))?;
            let plain = html_to_plain_text(&content);
            Ok(Intermediate::Paragraphs(split_paragraphs(&plain)))
        }
        "docx" => {
            let paragraphs = docx_util::extract_docx_paragraphs(path)?;
            Ok(Intermediate::Paragraphs(paragraphs))
        }
        "pdf" => {
            let paragraphs = pdf_util::extract_pdf_paragraphs(path)?;
            Ok(Intermediate::Paragraphs(paragraphs))
        }
        other => Err(format!(
            "暂不支持的源格式: .{}（仅支持 txt/md/html/docx/pdf）",
            other
        )),
    }
}

/// ---------- 渲染（Render）----------

pub fn render(intermediate: &Intermediate, target_ext: &str, out_path: &Path) -> Result<(), String> {
    match target_ext {
        "txt" => {
            let text = to_plain_text(intermediate);
            fs::write(out_path, text).map_err(|e| format!("写入 TXT 失败: {}", e))
        }
        "md" => {
            let text = to_markdown_text(intermediate);
            fs::write(out_path, text).map_err(|e| format!("写入 Markdown 失败: {}", e))
        }
        "html" => {
            let html = to_html(intermediate);
            fs::write(out_path, html).map_err(|e| format!("写入 HTML 失败: {}", e))
        }
        "pdf" => {
            let paragraphs = to_paragraphs(intermediate);
            pdf_util::write_pdf(&paragraphs, out_path)
        }
        "docx" => {
            let paragraphs = to_paragraphs(intermediate);
            docx_util::write_docx(&paragraphs, out_path)
        }
        other => Err(format!(
            "暂不支持的目标格式: .{}（仅支持 txt/md/html/docx/pdf）",
            other
        )),
    }
}

/// ---------- 中间表示之间的转换 ----------

pub fn to_paragraphs(intermediate: &Intermediate) -> Vec<String> {
    match intermediate {
        Intermediate::Paragraphs(p) => p.clone(),
        Intermediate::Markdown(md) => split_paragraphs(&markdown_to_plain_text(md)),
    }
}

pub fn to_plain_text(intermediate: &Intermediate) -> String {
    to_paragraphs(intermediate).join("\n\n")
}

pub fn to_markdown_text(intermediate: &Intermediate) -> String {
    match intermediate {
        Intermediate::Markdown(md) => md.clone(),
        Intermediate::Paragraphs(p) => p.join("\n\n"),
    }
}

pub fn to_html(intermediate: &Intermediate) -> String {
    let body = match intermediate {
        Intermediate::Markdown(md) => {
            let parser = pulldown_cmark::Parser::new(md);
            let mut html_out = String::new();
            pulldown_cmark::html::push_html(&mut html_out, parser);
            html_out
        }
        Intermediate::Paragraphs(paragraphs) => paragraphs
            .iter()
            .map(|p| format!("<p>{}</p>", escape_html(p).replace('\n', "<br/>")))
            .collect::<Vec<_>>()
            .join("\n"),
    };
    format!(
        "<!DOCTYPE html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"UTF-8\"/>\n<title>转换结果</title>\n<style>body{{font-family:sans-serif;max-width:800px;margin:40px auto;line-height:1.6;padding:0 16px;}}</style>\n</head>\n<body>\n{}\n</body>\n</html>\n",
        body
    )
}

/// ---------- 文本辅助函数 ----------

pub fn split_paragraphs(text: &str) -> Vec<String> {
    let paragraphs: Vec<String> = text
        .replace("\r\n", "\n")
        .split("\n\n")
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();
    if paragraphs.is_empty() && !text.trim().is_empty() {
        vec![text.trim().to_string()]
    } else {
        paragraphs
    }
}

fn escape_html(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;")
}

/// 将 Markdown 源码转换为纯文本（去除标记符号），用于 md -> txt/docx/pdf
pub fn markdown_to_plain_text(md: &str) -> String {
    let mut text = md.replace("\r\n", "\n");

    // 代码块 ```...``` 去掉围栏，保留内容
    let re_codefence = Regex::new(r"(?s)```[^\n]*\n(.*?)```").unwrap();
    text = re_codefence.replace_all(&text, "$1").to_string();

    // 行内代码 `code`
    let re_inline_code = Regex::new(r"`([^`]*)`").unwrap();
    text = re_inline_code.replace_all(&text, "$1").to_string();

    // 图片 ![alt](url) -> alt
    let re_img = Regex::new(r"!\[([^\]]*)\]\([^)]*\)").unwrap();
    text = re_img.replace_all(&text, "$1").to_string();

    // 链接 [text](url) -> text
    let re_link = Regex::new(r"\[([^\]]*)\]\([^)]*\)").unwrap();
    text = re_link.replace_all(&text, "$1").to_string();

    // 标题 #, ##, ...
    let re_heading = Regex::new(r"(?m)^#{1,6}\s*").unwrap();
    text = re_heading.replace_all(&text, "").to_string();

    // 粗体/斜体标记
    let re_emphasis = Regex::new(r"(\*\*\*|\*\*|\*|___|__|_)").unwrap();
    text = re_emphasis.replace_all(&text, "").to_string();

    // 列表符号
    let re_list = Regex::new(r"(?m)^\s*([-*+]|\d+\.)\s+").unwrap();
    text = re_list.replace_all(&text, "").to_string();

    // 引用符号
    let re_quote = Regex::new(r"(?m)^>\s?").unwrap();
    text = re_quote.replace_all(&text, "").to_string();

    // 水平分割线
    let re_hr = Regex::new(r"(?m)^(-{3,}|\*{3,}|_{3,})\s*$").unwrap();
    text = re_hr.replace_all(&text, "").to_string();

    text.trim().to_string()
}

/// 将 HTML 转换为纯文本（基于正则的轻量实现，不引入完整 HTML 解析器）
pub fn html_to_plain_text(html: &str) -> String {
    let mut text = html.to_string();

    // 去掉 <script>/<style> 整块内容
    let re_script = Regex::new(r"(?is)<(script|style)[^>]*>.*?</\1>").unwrap();
    text = re_script.replace_all(&text, "").to_string();

    // 块级标签开始 -> 换行
    let re_block_open =
        Regex::new(r"(?i)<(p|div|h[1-6]|li|tr|blockquote|section|article)[^>]*>").unwrap();
    text = re_block_open.replace_all(&text, "\n").to_string();

    // <br> -> 换行
    let re_br = Regex::new(r"(?i)<br\s*/?>").unwrap();
    text = re_br.replace_all(&text, "\n").to_string();

    // 块级标签结束 -> 换行
    let re_block_close =
        Regex::new(r"(?i)</(p|div|h[1-6]|li|tr|blockquote|section|article)>").unwrap();
    text = re_block_close.replace_all(&text, "\n").to_string();

    // 去掉其余所有标签
    let re_tags = Regex::new(r"(?s)<[^>]+>").unwrap();
    text = re_tags.replace_all(&text, "").to_string();

    // 常见实体解码
    text = decode_html_entities(&text);

    // 合并多余空行
    let re_blank = Regex::new(r"\n{3,}").unwrap();
    text = re_blank.replace_all(&text, "\n\n").to_string();

    text.trim().to_string()
}

fn decode_html_entities(s: &str) -> String {
    s.replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&apos;", "'")
}

/// 在指定目录下生成不冲突的输出路径：dir/stem.ext，若已存在则追加序号
pub fn unique_path(dir: &Path, stem: &str, ext: &str) -> PathBuf {
    let mut candidate = dir.join(format!("{}.{}", stem, ext));
    if !candidate.exists() {
        return candidate;
    }
    let mut i = 1;
    loop {
        candidate = dir.join(format!("{}_{}.{}", stem, i, ext));
        if !candidate.exists() {
            return candidate;
        }
        i += 1;
    }
}
