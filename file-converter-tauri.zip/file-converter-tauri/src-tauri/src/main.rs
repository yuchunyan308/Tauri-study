#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod converter;
mod docx_util;
mod pdf_util;

use serde::Serialize;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};

#[derive(Serialize, Clone)]
struct FileConvertResult {
    file_name: String,
    from_ext: String,
    to_ext: String,
    output_path: Option<String>,
    status: String, // "success" | "skipped" | "error"
    message: String,
}

#[derive(Serialize)]
struct ConvertSummary {
    total: usize,
    success: usize,
    skipped: usize,
    errors: usize,
    results: Vec<FileConvertResult>,
    verified: bool,
    verify_message: String,
    log_path: Option<String>,
}

#[tauri::command]
fn list_supported_formats() -> Vec<&'static str> {
    converter::SUPPORTED_FORMATS.to_vec()
}

/// 预览某个文件抽取出来的纯文本内容（截取前若干字符），供用户在转换前确认
#[tauri::command]
fn preview_text(path: String) -> Result<String, String> {
    let p = PathBuf::from(&path);
    let ext = p
        .extension()
        .and_then(|e| e.to_str())
        .map(converter::normalize_ext)
        .unwrap_or_default();
    let intermediate = converter::extract(&p, &ext)?;
    let text = converter::to_plain_text(&intermediate);
    let preview: String = text.chars().take(1000).collect();
    if preview.is_empty() {
        Ok("(未提取到可显示的文本内容)".to_string())
    } else {
        Ok(preview)
    }
}

#[tauri::command]
fn convert_files(paths: Vec<String>, target_format: String) -> Result<ConvertSummary, String> {
    let target_ext = converter::normalize_ext(&target_format);
    if !converter::SUPPORTED_FORMATS.contains(&target_ext.as_str()) {
        return Err(format!("不支持的目标格式: {}", target_format));
    }

    let mut results: Vec<FileConvertResult> = Vec::new();
    let mut success = 0usize;
    let mut skipped = 0usize;
    let mut errors = 0usize;

    for p in &paths {
        let path = PathBuf::from(p);
        let file_name = path
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("未知文件")
            .to_string();
        let source_ext = path
            .extension()
            .and_then(|e| e.to_str())
            .map(converter::normalize_ext)
            .unwrap_or_default();

        if source_ext == target_ext {
            skipped += 1;
            results.push(FileConvertResult {
                file_name,
                from_ext: source_ext,
                to_ext: target_ext.clone(),
                output_path: None,
                status: "skipped".to_string(),
                message: "源格式与目标格式相同，已跳过".to_string(),
            });
            continue;
        }

        let outcome: Result<PathBuf, String> = (|| {
            let intermediate = converter::extract(&path, &source_ext)?;
            let dir = path.parent().unwrap_or_else(|| Path::new("."));
            let stem = path
                .file_stem()
                .and_then(|s| s.to_str())
                .unwrap_or("output");
            let out_path = converter::unique_path(dir, stem, &target_ext);
            converter::render(&intermediate, &target_ext, &out_path)?;
            Ok(out_path)
        })();

        match outcome {
            Ok(out_path) => {
                success += 1;
                results.push(FileConvertResult {
                    file_name,
                    from_ext: source_ext,
                    to_ext: target_ext.clone(),
                    output_path: Some(out_path.to_string_lossy().to_string()),
                    status: "success".to_string(),
                    message: "转换成功".to_string(),
                });
            }
            Err(e) => {
                errors += 1;
                results.push(FileConvertResult {
                    file_name,
                    from_ext: source_ext,
                    to_ext: target_ext.clone(),
                    output_path: None,
                    status: "error".to_string(),
                    message: e,
                });
            }
        }
    }

    // ---------- 自检 (Self-check) ----------
    let mut verify_errors: Vec<String> = Vec::new();

    if success + skipped + errors != paths.len() {
        verify_errors.push(format!(
            "计数校验失败: success({}) + skipped({}) + errors({}) != total({})",
            success,
            skipped,
            errors,
            paths.len()
        ));
    }

    for r in &results {
        if r.status == "success" {
            match &r.output_path {
                Some(op) => {
                    let out_p = Path::new(op);
                    if !out_p.exists() {
                        verify_errors.push(format!("输出文件不存在，疑似丢失: {}", op));
                    } else {
                        match fs::metadata(out_p) {
                            Ok(meta) if meta.len() == 0 => {
                                verify_errors.push(format!("输出文件大小为 0: {}", op));
                            }
                            Err(e) => {
                                verify_errors.push(format!("无法读取输出文件元信息: {} ({})", op, e));
                            }
                            _ => {}
                        }
                    }
                }
                None => {
                    verify_errors.push(format!("{} 标记为成功但缺少输出路径", r.file_name));
                }
            }
        }
    }

    let verified = verify_errors.is_empty();
    let verify_message = if verified {
        format!(
            "自检通过：共 {} 个文件，成功转换 {} 个，跳过 {} 个，出错 {} 个。",
            paths.len(),
            success,
            skipped,
            errors
        )
    } else {
        format!(
            "自检发现 {} 个问题：\n{}",
            verify_errors.len(),
            verify_errors.join("\n")
        )
    };

    let log_path = write_log(&paths, &results, &verify_message);

    Ok(ConvertSummary {
        total: paths.len(),
        success,
        skipped,
        errors,
        results,
        verified,
        verify_message,
        log_path,
    })
}

fn write_log(paths: &[String], results: &[FileConvertResult], verify_message: &str) -> Option<String> {
    let dir = paths
        .first()
        .and_then(|p| Path::new(p).parent())
        .map(|p| p.to_path_buf())
        .unwrap_or_else(|| PathBuf::from("."));

    let now = chrono::Local::now();
    let log_name = format!("转换日志_{}.txt", now.format("%Y%m%d_%H%M%S"));
    let log_path = dir.join(log_name);

    let mut content = String::new();
    content.push_str(&format!(
        "文件互转助手 - 操作日志\n生成时间: {}\n\n{}\n\n详细记录:\n",
        now.format("%Y-%m-%d %H:%M:%S"),
        verify_message
    ));
    for r in results {
        content.push_str(&format!(
            "[{}] {} ({} -> {}) {} {}\n",
            r.status,
            r.file_name,
            r.from_ext,
            r.to_ext,
            r.output_path.clone().unwrap_or_default(),
            r.message
        ));
    }

    match fs::File::create(&log_path).and_then(|mut f| f.write_all(content.as_bytes())) {
        Ok(_) => Some(log_path.to_string_lossy().to_string()),
        Err(_) => None,
    }
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .invoke_handler(tauri::generate_handler![
            list_supported_formats,
            preview_text,
            convert_files
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
