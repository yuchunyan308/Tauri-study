import { invoke } from "@tauri-apps/api/core";
import { open } from "@tauri-apps/plugin-dialog";

const pickBtn = document.getElementById("pickBtn");
const fileCountEl = document.getElementById("fileCount");
const fileListEl = document.getElementById("fileList");
const targetFormatEl = document.getElementById("targetFormat");
const convertBtn = document.getElementById("convertBtn");
const statusText = document.getElementById("statusText");

const previewSection = document.getElementById("previewSection");
const previewFileName = document.getElementById("previewFileName");
const previewText = document.getElementById("previewText");

const resultSection = document.getElementById("resultSection");
const summaryEl = document.getElementById("summary");
const verifyBox = document.getElementById("verifyBox");
const resultTableBody = document.querySelector("#resultTable tbody");

const SUPPORTED_EXTENSIONS = ["txt", "md", "markdown", "html", "htm", "docx", "pdf"];

let selectedFiles = []; // [{ path, name, ext }]

function getExt(path) {
  const name = path.split(/[\\/]/).pop();
  const idx = name.lastIndexOf(".");
  return idx >= 0 ? name.slice(idx + 1).toLowerCase() : "";
}

function getName(path) {
  return path.split(/[\\/]/).pop();
}

pickBtn.addEventListener("click", async () => {
  try {
    const selected = await open({
      directory: false,
      multiple: true,
      filters: [
        {
          name: "支持的文档格式",
          extensions: SUPPORTED_EXTENSIONS,
        },
      ],
    });
    if (selected) {
      const paths = Array.isArray(selected) ? selected : [selected];
      for (const p of paths) {
        if (!selectedFiles.some((f) => f.path === p)) {
          selectedFiles.push({ path: p, name: getName(p), ext: getExt(p) });
        }
      }
      renderFileList();
    }
  } catch (e) {
    statusText.textContent = "选择文件失败: " + e;
  }
});

function renderFileList() {
  fileCountEl.textContent = selectedFiles.length
    ? `已选择 ${selectedFiles.length} 个文件`
    : "尚未选择文件";
  convertBtn.disabled = selectedFiles.length === 0;

  fileListEl.innerHTML = "";
  selectedFiles.forEach((f, idx) => {
    const row = document.createElement("div");
    row.className = "file-item";
    row.innerHTML = `
      <span class="ext-badge">${f.ext || "?"}</span>
      <span class="name" title="${escapeAttr(f.path)}">${escapeHtml(f.name)}</span>
      <button class="remove-btn" data-idx="${idx}">✕</button>
    `;
    row.addEventListener("click", (e) => {
      if (e.target.classList.contains("remove-btn")) return;
      showPreview(f);
    });
    row.querySelector(".remove-btn").addEventListener("click", (e) => {
      e.stopPropagation();
      selectedFiles.splice(idx, 1);
      renderFileList();
    });
    fileListEl.appendChild(row);
  });
}

async function showPreview(file) {
  previewSection.classList.remove("hidden");
  previewFileName.textContent = file.name;
  previewText.textContent = "正在提取内容...";
  try {
    const text = await invoke("preview_text", { path: file.path });
    previewText.textContent = text;
  } catch (e) {
    previewText.textContent = "预览失败: " + e;
  }
}

convertBtn.addEventListener("click", async () => {
  if (selectedFiles.length === 0) return;
  const targetFormat = targetFormatEl.value;

  setBusy(true, "正在转换，请稍候...");
  try {
    const result = await invoke("convert_files", {
      paths: selectedFiles.map((f) => f.path),
      targetFormat,
    });
    renderResult(result);
    statusText.textContent = result.verified
      ? "转换完成，自检通过 ✅"
      : "转换完成，但自检发现问题，请查看下方详情 ⚠️";
  } catch (e) {
    statusText.textContent = "转换失败: " + e;
  } finally {
    setBusy(false);
  }
});

function setBusy(busy, text) {
  pickBtn.disabled = busy;
  convertBtn.disabled = busy || selectedFiles.length === 0;
  if (text) statusText.textContent = text;
}

function renderResult(result) {
  resultSection.classList.remove("hidden");

  summaryEl.innerHTML = `
    <div class="stat">文件总数<b>${result.total}</b></div>
    <div class="stat">转换成功<b>${result.success}</b></div>
    <div class="stat">跳过<b>${result.skipped}</b></div>
    <div class="stat">出错<b>${result.errors}</b></div>
  `;

  verifyBox.className = "verify-box " + (result.verified ? "ok" : "fail");
  verifyBox.textContent =
    result.verify_message + (result.log_path ? `\n详细日志已保存至: ${result.log_path}` : "");

  resultTableBody.innerHTML = "";
  for (const r of result.results) {
    const tr = document.createElement("tr");
    const detail = r.status === "success" ? r.output_path : r.message;
    tr.innerHTML = `
      <td><span class="status-badge ${r.status}">${statusLabel(r.status)}</span></td>
      <td>${escapeHtml(r.file_name)}</td>
      <td>${r.from_ext.toUpperCase()} → ${r.to_ext.toUpperCase()}</td>
      <td>${escapeHtml(detail || "")}</td>
    `;
    resultTableBody.appendChild(tr);
  }
}

function statusLabel(status) {
  switch (status) {
    case "success": return "成功";
    case "skipped": return "跳过";
    case "error": return "出错";
    default: return status;
  }
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

function escapeAttr(str) {
  return (str ?? "").replace(/"/g, "&quot;");
}
