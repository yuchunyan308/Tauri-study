# 📁 文件归类助手（Tauri 版）

一个基于 **Tauri 2 + Rust + 原生前端** 的本地文件自动归类整理小工具。
选择一个文件夹后，会按照文件类型（扩展名）自动把文件分拣到对应子文件夹中，例如：

| 分类文件夹 | 包含的扩展名（举例） |
|---|---|
| 图片_Images | jpg, jpeg, png, gif, bmp, webp, svg, tiff, heic ... |
| 视频_Videos | mp4, avi, mov, mkv, flv, wmv, webm ... |
| 音频_Audio | mp3, wav, flac, aac, ogg, m4a ... |
| 文档_Documents | pdf, doc/docx, xls/xlsx, ppt/pptx, txt, csv, md ... |
| 压缩包_Archives | zip, rar, 7z, tar, gz ... |
| 代码_Code | js, ts, py, java, c/cpp, html, css, json ... |
| 程序_Executables | exe, msi, dmg, apk, deb ... |
| 字体_Fonts | ttf, otf, woff/woff2 |
| 其他_Others | 未匹配到以上分类的文件 |

## ✨ 功能特点

- **一键选择文件夹**，支持“仅当前层级”或“包含子文件夹”两种扫描模式
- **移动 / 复制** 两种整理模式可选
- **预览模式**：整理前可先查看将会如何分类，不修改任何文件
- **自动去重命名**：目标文件夹若已存在同名文件，会自动追加序号（如 `photo_1.jpg`），不会覆盖或丢失文件
- **自检机制**：整理完成后自动校验——
  1. 扫描总数 = 处理成功数 + 跳过数 + 出错数
  2. 所有标记为“已移动/已复制”的文件，目标路径必须真实存在
  3. “移动”模式下，原文件必须已不存在（防止重复）
  4. 自检结果会在界面上以 ✅ / ⚠️ 提示，并写入整理目标文件夹内的 `整理日志_时间戳.txt`
- 已归类的子文件夹（如 `图片_Images`）不会被二次归类，避免死循环

## ⚠️ 关于本压缩包 —— 重要说明

**本环境（沙箱）没有联网权限，也没有安装 Rust/Cargo 工具链**，因此我**无法在这里直接编译出可双击运行的
`.exe / .dmg / .AppImage` 安装包**。压缩包里提供的是**完整、可直接构建的 Tauri 项目源代码**——这是唯一诚实可行的交付方式，请见谅。

好消息是：Tauri 项目构建非常标准化，你在自己电脑上按下面步骤操作，**10 分钟内**就能得到真正的原生安装包。

## 🔧 本地构建步骤

### 1. 安装前置环境（只需一次）

- **Node.js** 18+：https://nodejs.org
- **Rust**：https://www.rust-lang.org/tools/install （安装后重启终端）
- **系统依赖**（Tauri 官方要求）：
  - Windows：安装 [Microsoft Visual Studio C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/) 及 WebView2（Win10/11 通常已自带）
  - macOS：安装 Xcode Command Line Tools：`xcode-select --install`
  - Linux：参考 https://tauri.app/start/prerequisites/ 安装 `libwebkit2gtk`、`libgtk-3-dev` 等依赖

### 2. 解压并安装依赖

```bash
# 解压后进入项目目录
cd file-organizer-tauri

# 安装前端依赖
npm install
```

### 3. 开发模式运行（可直接体验）

```bash
npm run dev
```

### 4. 正式打包成安装包

```bash
npm run build
```

打包完成后，安装包会出现在：

```
src-tauri/target/release/bundle/
```

- Windows → `nsis/*.exe` 或 `msi/*.msi`（双击安装）
- macOS → `dmg/*.dmg`（双击安装）
- Linux → `deb/*.deb`、`appimage/*.AppImage`（双击/命令行安装运行）

打包完成后即可在对应系统上**双击安装并启动**，无需再安装 Node/Rust 环境。

## 📂 项目结构

```
file-organizer-tauri/
├── package.json              # 前端依赖与脚本
├── src/                      # 前端界面（原生 HTML/CSS/JS，无需构建工具）
│   ├── index.html
│   ├── style.css
│   └── main.js
└── src-tauri/                # Rust 后端 + Tauri 配置
    ├── Cargo.toml
    ├── build.rs
    ├── tauri.conf.json
    ├── capabilities/default.json
    ├── icons/                 # 应用图标（已生成）
    └── src/main.rs            # 核心分类/自检逻辑
```

## 🧪 我在提交前做的自检

1. **代码走查**：逐行检查了 `main.rs` 的分类映射、去重命名、move/copy 回退逻辑（跨磁盘 rename 失败自动回退为 copy+delete）、以及自检校验函数，逻辑闭环、无死循环。
2. **配置校验**：`Cargo.toml`、`tauri.conf.json`、`capabilities/default.json` 均按 Tauri 2.x 官方 schema 编写，字段拼写和依赖版本经过核对。
3. **图标生成**：已用 Pillow 生成了 `32x32.png / 128x128.png / 128x128@2x.png / icon.ico / icon.icns`，打包不会因缺图标而失败。
4. **未做到的**：由于沙箱无网络、无 Rust 工具链，**未能实际执行 `cargo build` 编译验证**。这是本次交付唯一的局限，已在上方如实说明——请你在本地 `npm run build` 时留意终端报错（如有，多半是 Tauri/Rust 版本细微差异导致，把报错发给我，我可以帮你继续排查修复）。

## 🛡️ 使用建议

- 首次使用建议先点击「预览分类结果」确认无误，再执行「开始整理」
- 重要文件建议先用「复制」模式验证效果，确认无误后再用「移动」模式清理原文件夹
