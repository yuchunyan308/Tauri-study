// Prevents additional console window on Windows in release
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};

/// 分类规则：扩展名(小写，不含点) -> 分类文件夹名
fn category_map() -> HashMap<&'static str, &'static str> {
    let mut m = HashMap::new();

    let images = [
        "jpg", "jpeg", "png", "gif", "bmp", "webp", "svg", "tif", "tiff", "ico", "heic", "heif",
        "raw", "psd",
    ];
    let videos = [
        "mp4", "avi", "mov", "mkv", "flv", "wmv", "webm", "m4v", "mpg", "mpeg", "3gp", "ts",
    ];
    let audio = [
        "mp3", "wav", "flac", "aac", "ogg", "wma", "m4a", "opus", "aiff",
    ];
    let documents = [
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "ods",
        "odp", "md",
    ];
    let archives = [
        "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso",
    ];
    let code = [
        "js", "ts", "jsx", "tsx", "py", "java", "c", "cpp", "h", "hpp", "html", "css", "json",
        "xml", "sh", "go", "rs", "php", "rb", "yml", "yaml", "sql", "vue",
    ];
    let executables = ["exe", "msi", "dmg", "app", "apk", "deb", "appimage"];
    let fonts = ["ttf", "otf", "woff", "woff2"];

    for e in images {
        m.insert(e, "图片_Images");
    }
    for e in videos {
        m.insert(e, "视频_Videos");
    }
    for e in audio {
        m.insert(e, "音频_Audio");
    }
    for e in documents {
        m.insert(e, "文档_Documents");
    }
    for e in archives {
        m.insert(e, "压缩包_Archives");
    }
    for e in code {
        m.insert(e, "代码_Code");
    }
    for e in executables {
        m.insert(e, "程序_Executables");
    }
    for e in fonts {
        m.insert(e, "字体_Fonts");
    }
    m
}

/// 已经存在的分类文件夹名集合，避免对分类结果二次分类
fn known_category_folders() -> Vec<&'static str> {
    vec![
        "图片_Images",
        "视频_Videos",
        "音频_Audio",
        "文档_Documents",
        "压缩包_Archives",
        "代码_Code",
        "程序_Executables",
        "字体_Fonts",
        "其他_Others",
    ]
}

#[derive(Serialize, Deserialize, Clone)]
struct FileAction {
    file_name: String,
    from: String,
    to: String,
    category: String,
    status: String, // "moved" | "copied" | "skipped" | "error"
    message: Option<String>,
}

#[derive(Serialize, Deserialize)]
struct OrganizeResult {
    total_scanned: usize,
    processed: usize,
    skipped: usize,
    errors: usize,
    category_counts: HashMap<String, usize>,
    actions: Vec<FileAction>,
    verified: bool,
    verify_message: String,
    log_path: Option<String>,
}

fn get_extension_lower(path: &Path) -> Option<String> {
    path.extension()
        .and_then(|e| e.to_str())
        .map(|s| s.to_lowercase())
}

fn unique_dest_path(dest_dir: &Path, file_name: &str) -> PathBuf {
    let mut candidate = dest_dir.join(file_name);
    if !candidate.exists() {
        return candidate;
    }
    let stem = Path::new(file_name)
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or(file_name)
        .to_string();
    let ext = Path::new(file_name)
        .extension()
        .and_then(|s| s.to_str())
        .map(|s| format!(".{}", s))
        .unwrap_or_default();
    let mut i = 1;
    loop {
        let new_name = format!("{}_{}{}", stem, i, ext);
        candidate = dest_dir.join(&new_name);
        if !candidate.exists() {
            return candidate;
        }
        i += 1;
    }
}

fn collect_files(root: &Path, include_subfolders: bool) -> Vec<PathBuf> {
    let mut result = Vec::new();
    let category_folders = known_category_folders();

    if include_subfolders {
        for entry in walkdir::WalkDir::new(root)
            .into_iter()
            .filter_map(|e| e.ok())
        {
            let path = entry.path();
            if path.is_file() {
                // 跳过已经位于分类文件夹内的文件，避免重复归类
                let in_category_folder = path.components().any(|c| {
                    if let std::path::Component::Normal(os) = c {
                        if let Some(s) = os.to_str() {
                            return category_folders.contains(&s);
                        }
                    }
                    false
                });
                if !in_category_folder {
                    result.push(path.to_path_buf());
                }
            }
        }
    } else if let Ok(entries) = fs::read_dir(root) {
        for entry in entries.filter_map(|e| e.ok()) {
            let path = entry.path();
            if path.is_file() {
                result.push(path);
            }
        }
    }
    result
}

#[tauri::command]
fn preview_organize(target_dir: String, include_subfolders: bool) -> Result<OrganizeResult, String> {
    let root = PathBuf::from(&target_dir);
    if !root.is_dir() {
        return Err("所选路径不是有效的文件夹".to_string());
    }
    let cat_map = category_map();
    let files = collect_files(&root, include_subfolders);

    let mut actions = Vec::new();
    let mut category_counts: HashMap<String, usize> = HashMap::new();

    for file in &files {
        let file_name = file
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("未知文件")
            .to_string();
        let ext = get_extension_lower(file);
        let category = match ext.as_deref().and_then(|e| cat_map.get(e)) {
            Some(c) => c.to_string(),
            None => "其他_Others".to_string(),
        };
        *category_counts.entry(category.clone()).or_insert(0) += 1;
        let dest_dir = root.join(&category);
        actions.push(FileAction {
            file_name,
            from: file.to_string_lossy().to_string(),
            to: dest_dir.to_string_lossy().to_string(),
            category,
            status: "preview".to_string(),
            message: None,
        });
    }

    Ok(OrganizeResult {
        total_scanned: files.len(),
        processed: 0,
        skipped: 0,
        errors: 0,
        category_counts,
        actions,
        verified: true,
        verify_message: "预览模式，未做任何改动".to_string(),
        log_path: None,
    })
}

#[tauri::command]
fn organize_files(
    target_dir: String,
    mode: String, // "move" or "copy"
    include_subfolders: bool,
) -> Result<OrganizeResult, String> {
    let root = PathBuf::from(&target_dir);
    if !root.is_dir() {
        return Err("所选路径不是有效的文件夹".to_string());
    }

    let cat_map = category_map();
    let files = collect_files(&root, include_subfolders);
    let total_scanned = files.len();

    let mut actions: Vec<FileAction> = Vec::new();
    let mut category_counts: HashMap<String, usize> = HashMap::new();
    let mut processed = 0usize;
    let mut skipped = 0usize;
    let mut errors = 0usize;

    for file in &files {
        let file_name = file
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("未知文件")
            .to_string();

        let ext = get_extension_lower(file);
        let category = match ext.as_deref().and_then(|e| cat_map.get(e)) {
            Some(c) => c.to_string(),
            None => "其他_Others".to_string(),
        };

        let dest_dir = root.join(&category);

        if let Err(e) = fs::create_dir_all(&dest_dir) {
            errors += 1;
            actions.push(FileAction {
                file_name,
                from: file.to_string_lossy().to_string(),
                to: dest_dir.to_string_lossy().to_string(),
                category,
                status: "error".to_string(),
                message: Some(format!("创建目标文件夹失败: {}", e)),
            });
            continue;
        }

        let dest_path = unique_dest_path(&dest_dir, &file_name);

        let op_result = if mode == "copy" {
            fs::copy(file, &dest_path).map(|_| ())
        } else {
            // 优先尝试 rename（同盘更快），失败则回退到 copy+delete（跨盘场景）
            match fs::rename(file, &dest_path) {
                Ok(_) => Ok(()),
                Err(_) => fs::copy(file, &dest_path)
                    .and_then(|_| fs::remove_file(file))
                    .map(|_| ()),
            }
        };

        match op_result {
            Ok(_) => {
                processed += 1;
                *category_counts.entry(category.clone()).or_insert(0) += 1;
                actions.push(FileAction {
                    file_name,
                    from: file.to_string_lossy().to_string(),
                    to: dest_path.to_string_lossy().to_string(),
                    category,
                    status: if mode == "copy" { "copied".to_string() } else { "moved".to_string() },
                    message: None,
                });
            }
            Err(e) => {
                errors += 1;
                actions.push(FileAction {
                    file_name,
                    from: file.to_string_lossy().to_string(),
                    to: dest_path.to_string_lossy().to_string(),
                    category,
                    status: "error".to_string(),
                    message: Some(format!("{}", e)),
                });
            }
        }
    }

    skipped = total_scanned.saturating_sub(processed + errors);

    // ---------- 自检 (Self-check) ----------
    // 1. 校验：processed + errors + skipped 是否等于扫描到的文件总数
    // 2. 校验：move 模式下，原文件应不再存在；copy 模式下，原文件应仍然存在
    // 3. 校验：所有标记为 moved/copied 的文件，目标路径必须真实存在
    let mut verify_errors: Vec<String> = Vec::new();

    if processed + errors + skipped != total_scanned {
        verify_errors.push(format!(
            "计数校验失败: processed({}) + errors({}) + skipped({}) != total_scanned({})",
            processed, errors, skipped, total_scanned
        ));
    }

    for action in &actions {
        if action.status == "moved" || action.status == "copied" {
            let to_path = Path::new(&action.to);
            if !to_path.exists() {
                verify_errors.push(format!(
                    "目标文件不存在，疑似丢失: {} -> {}",
                    action.file_name, action.to
                ));
            }
            if action.status == "moved" {
                let from_path = Path::new(&action.from);
                if from_path.exists() {
                    verify_errors.push(format!(
                        "移动模式下原文件仍然存在（可能重复）: {}",
                        action.from
                    ));
                }
            }
        }
    }

    let verified = verify_errors.is_empty();
    let verify_message = if verified {
        format!(
            "自检通过：共扫描 {} 个文件，成功处理 {} 个，跳过 {} 个，出错 {} 个。",
            total_scanned, processed, skipped, errors
        )
    } else {
        format!("自检发现 {} 个问题：\n{}", verify_errors.len(), verify_errors.join("\n"))
    };

    // ---------- 写入日志文件 ----------
    let log_path = write_log(&root, &actions, total_scanned, processed, skipped, errors, &verify_message);

    Ok(OrganizeResult {
        total_scanned,
        processed,
        skipped,
        errors,
        category_counts,
        actions,
        verified,
        verify_message,
        log_path,
    })
}

fn write_log(
    root: &Path,
    actions: &[FileAction],
    total_scanned: usize,
    processed: usize,
    skipped: usize,
    errors: usize,
    verify_message: &str,
) -> Option<String> {
    let now = chrono::Local::now();
    let file_name = format!("整理日志_{}.txt", now.format("%Y%m%d_%H%M%S"));
    let log_path = root.join(&file_name);

    let mut content = String::new();
    content.push_str(&format!("文件归类助手 - 操作日志\n生成时间: {}\n\n", now.format("%Y-%m-%d %H:%M:%S")));
    content.push_str(&format!(
        "扫描文件总数: {}\n处理成功: {}\n跳过: {}\n出错: {}\n\n{}\n\n",
        total_scanned, processed, skipped, errors, verify_message
    ));
    content.push_str("详细记录:\n");
    for a in actions {
        content.push_str(&format!(
            "[{}] {} | {} -> {} {}\n",
            a.status,
            a.file_name,
            a.from,
            a.to,
            a.message.clone().unwrap_or_default()
        ));
    }

    match fs::File::create(&log_path).and_then(|mut f| f.write_all(content.as_bytes())) {
        Ok(_) => Some(log_path.to_string_lossy().to_string()),
        Err(_) => None,
    }
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .invoke_handler(tauri::generate_handler![preview_organize, organize_files])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
