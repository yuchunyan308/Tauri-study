import { invoke } from "@tauri-apps/api/core";
import { open } from "@tauri-apps/plugin-dialog";

const pickBtn = document.getElementById("pickBtn");
const previewBtn = document.getElementById("previewBtn");
const organizeBtn = document.getElementById("organizeBtn");
const targetPathEl = document.getElementById("targetPath");
const includeSubEl = document.getElementById("includeSub");
const statusText = document.getElementById("statusText");
const resultSection = document.getElementById("resultSection");
const summaryEl = document.getElementById("summary");
const verifyBox = document.getElementById("verifyBox");
const resultTableBody = document.querySelector("#resultTable tbody");

let targetDir = null;

function getMode() {
  return document.querySelector('input[name="mode"]:checked').value;
}

pickBtn.addEventListener("click", async () => {
  try {
    const selected = await open({ directory: true, multiple: false });
    if (selected) {
      targetDir = selected;
      targetPathEl.textContent = targetDir;
      previewBtn.disabled = false;
      organizeBtn.disabled = false;
      statusText.textContent = "已选择文件夹，可先点击“预览分类结果”查看效果";
    }
  } catch (e) {
    statusText.textContent = "选择文件夹失败: " + e;
  }
});

previewBtn.addEventListener("click", async () => {
  if (!targetDir) return;
  setBusy(true, "正在扫描文件...");
  try {
    const result = await invoke("preview_organize", {
      targetDir,
      includeSubfolders: includeSubEl.checked,
    });
    renderResult(result, true);
    statusText.textContent = "预览完成（未修改任何文件），确认无误后点击“开始整理”";
  } catch (e) {
    statusText.textContent = "预览失败: " + e;
  } finally {
    setBusy(false);
  }
});

organizeBtn.addEventListener("click", async () => {
  if (!targetDir) return;
  const mode = getMode();
  const confirmMsg =
    mode === "move"
      ? "即将【移动】文件到分类文件夹，原位置将不再保留原文件，确定继续吗？"
      : "即将【复制】文件到分类文件夹，原文件保持不动，确定继续吗？";
  if (!window.confirm(confirmMsg)) return;

  setBusy(true, "正在整理文件，请稍候...");
  try {
    const result = await invoke("organize_files", {
      targetDir,
      mode,
      includeSubfolders: includeSubEl.checked,
    });
    renderResult(result, false);
    statusText.textContent = result.verified
      ? "整理完成，自检通过 ✅"
      : "整理完成，但自检发现问题，请查看下方详情 ⚠️";
  } catch (e) {
    statusText.textContent = "整理失败: " + e;
  } finally {
    setBusy(false);
  }
});

function setBusy(busy, text) {
  pickBtn.disabled = busy;
  previewBtn.disabled = busy || !targetDir;
  organizeBtn.disabled = busy || !targetDir;
  if (text) statusText.textContent = text;
}

function renderResult(result, isPreview) {
  resultSection.classList.remove("hidden");

  const categoryHtml = Object.entries(result.category_counts || {})
    .map(([cat, count]) => `<div class="stat">${cat}<b>${count}</b></div>`)
    .join("");

  summaryEl.innerHTML = `
    <div class="stat">扫描文件总数<b>${result.total_scanned}</b></div>
    <div class="stat">${isPreview ? "预计分类" : "已处理"}<b>${isPreview ? result.total_scanned : result.processed}</b></div>
    <div class="stat">跳过<b>${result.skipped}</b></div>
    <div class="stat">出错<b>${result.errors}</b></div>
    ${categoryHtml}
  `;

  if (isPreview) {
    verifyBox.className = "verify-box";
    verifyBox.style.display = "none";
  } else {
    verifyBox.style.display = "block";
    verifyBox.className = "verify-box " + (result.verified ? "ok" : "fail");
    verifyBox.textContent =
      result.verify_message + (result.log_path ? `\n详细日志已保存至: ${result.log_path}` : "");
  }

  resultTableBody.innerHTML = "";
  for (const action of result.actions) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><span class="status-badge ${action.status}">${statusLabel(action.status)}</span></td>
      <td>${escapeHtml(action.file_name)}</td>
      <td>${escapeHtml(action.category)}</td>
      <td>${escapeHtml(action.to)}</td>
    `;
    resultTableBody.appendChild(tr);
  }
}

function statusLabel(status) {
  switch (status) {
    case "moved": return "已移动";
    case "copied": return "已复制";
    case "error": return "出错";
    case "preview": return "预览";
    default: return status;
  }
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}
